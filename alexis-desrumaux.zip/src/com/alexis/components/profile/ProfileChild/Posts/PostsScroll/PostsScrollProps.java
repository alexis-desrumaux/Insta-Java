package com.alexis.components.profile.ProfileChild.Posts.PostsScroll;

import java.awt.*;
import com.alexis.common.ComponentProps.ComponentProps;

public class PostsScrollProps extends ComponentProps {
  public final static String TYPE_NAME = "PostsScrollProps";

  public PostsScrollProps() {
    super(TYPE_NAME);
  }
}
