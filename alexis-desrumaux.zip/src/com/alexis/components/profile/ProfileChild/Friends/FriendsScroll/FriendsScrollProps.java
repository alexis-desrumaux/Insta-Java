package com.alexis.components.profile.ProfileChild.Friends.FriendsScroll;

import java.awt.*;
import com.alexis.common.ComponentProps.ComponentProps;

public class FriendsScrollProps extends ComponentProps {
  public final static String TYPE_NAME = "FriendsScrollProps";

  public FriendsScrollProps() {
    super(TYPE_NAME);
  }
}
