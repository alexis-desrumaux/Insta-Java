package com.alexis.common.ComponentProps;

public class ComponentProps {
  private String propsTypeName;

  public String getPropsTypeName() {
    return this.propsTypeName;
  }

  public ComponentProps(String propsTypeName) {
    this.propsTypeName = propsTypeName;
  }
}
